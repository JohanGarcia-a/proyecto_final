package model;

public enum ROLE {

    ADMINISTRATOR,
    EMPLOYEE,
    GENERAL
}