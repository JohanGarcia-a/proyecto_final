package controlador;

import model.ModeloTablaReporteVentas;
import model.Venta;
import model.VentaDAO;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.view.JasperViewer;
import vista.PanelReporteVentas;

import javax.swing.*;
import java.io.InputStream;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ControladorReporteVentas {
    private final PanelReporteVentas vista;
    private final VentaDAO daoVentas;
    private final ModeloTablaReporteVentas modeloTabla;

    // *** NUEVO: DataSource de beans en vez de Connection JDBC
    private JRBeanCollectionDataSource beanDataSource;

    // Plantilla JRXML y parámetros (aunque no usemos query SQL)
    private String jasperTemplatePath;
    private Map<String,Object> lastParameters;

    private static final DateTimeFormatter FMT_DIARIO  = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter FMT_MENSUAL = DateTimeFormatter.ofPattern("yyyy-MM");

    public ControladorReporteVentas(PanelReporteVentas vista) throws SQLException {
        this.vista      = vista;
        this.daoVentas  = new VentaDAO();
        this.modeloTabla= (ModeloTablaReporteVentas) vista.tblReporte.getModel();

        vista.btnCargarDiario .addActionListener(e -> cargarReporteDiario());
        vista.btnCargarMensual.addActionListener(e -> cargarReporteMensual());
        vista.btnExportarPDF  .addActionListener(e -> mostrarReporteEnPantalla());
    }

    private void cargarReporteDiario() {
        LocalDate ld = ((java.util.Date) vista.spnFecha.getValue())
                .toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        String turno = (String) vista.cbTurno.getSelectedItem();

        try {
            List<Venta> ventas;
            if ("Matutino (08:00–14:00)".equals(turno)) {
                ventas = daoVentas.buscarPorFechaYHorario(ld, "08:00", "14:00");
            } else if ("Vespertino (14:00–20:00)".equals(turno)) {
                ventas = daoVentas.buscarPorFechaYHorario(ld, "14:00", "20:00");
            } else {
                ventas = daoVentas.buscarPorFecha(ld);
            }

            // 1) Actualiza la tabla y el resumen
            modeloTabla.setVentas(ventas);
            actualizarResumen(ventas);

            // 2) Prepara el JRBeanCollectionDataSource
            beanDataSource = new JRBeanCollectionDataSource(ventas);

            // 3) (Opcional) puedes pasar parámetros si tu JRXML los usa
            Map<String,Object> params = new HashMap<>();
            params.put("TITULO", "Reporte Diario: " + ld.format(FMT_DIARIO));
            this.lastParameters      = params;
            this.jasperTemplatePath  = "/Reportes/ReporteVentas.jrxml";

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(vista,
                    "Error al cargar reporte diario:\n" + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarReporteMensual() {
        LocalDate ld = ((java.util.Date) vista.spnMes.getValue())
                .toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        YearMonth ym = YearMonth.of(ld.getYear(), ld.getMonth());

        try {
            List<Venta> ventas = daoVentas.buscarPorMes(ym);
            modeloTabla.setVentas(ventas);
            actualizarResumen(ventas);

            beanDataSource = new JRBeanCollectionDataSource(ventas);

            Map<String,Object> params = new HashMap<>();
            params.put("TITULO", "Reporte Mensual: " + ym.format(FMT_MENSUAL));
            this.lastParameters     = params;
            this.jasperTemplatePath = "/Reportes/ReporteVentas.jrxml";

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(vista,
                    "Error al cargar reporte mensual:\n" + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarResumen(List<Venta> ventas) {
        double totalSub = ventas.stream().mapToDouble(Venta::getTotal).sum();
        double totalIva = totalSub * 0.16;
        double totalGen = totalSub + totalIva;

        vista.lblTotalSubtotal.setText(String.format("Total Subtotal: $%.2f", totalSub));
        vista.lblTotalIva     .setText(String.format("Total IVA:      $%.2f", totalIva));
        vista.lblIngresoTotal .setText(String.format("Ingreso Total:  $%.2f", totalGen));
    }

    public void mostrarReporteEnPantalla() {
        if (jasperTemplatePath == null || beanDataSource == null) {
            JOptionPane.showMessageDialog(vista,
                    "Primero genera el reporte Diario o Mensual.",
                    "Información", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        try (InputStream jrxml = getClass().getResourceAsStream(jasperTemplatePath)) {
            if (jrxml == null) throw new RuntimeException("No se encontró: " + jasperTemplatePath);

            JasperReport  report    = JasperCompileManager.compileReport(jrxml);
            JasperPrint   print     = JasperFillManager.fillReport(
                    report,
                    lastParameters,
                    beanDataSource
            );

            if (print.getPages().isEmpty()) {
                JOptionPane.showMessageDialog(vista,
                        "El reporte no generó ninguna página.",
                        "Sin datos", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            JasperViewer viewer = new JasperViewer(print, false);
            viewer.setTitle("Previsualización de Reporte");
            viewer.setVisible(true);

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(vista,
                    "Error al generar el reporte:\n" + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
